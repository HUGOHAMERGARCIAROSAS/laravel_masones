<style>
    body {
        display: grid;
        grid-template-rows: 1fr auto; 
        min-height: 100vh;
        margin: 0;
    }
</style>
<div class="container-fluid copyright bg-dark py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center mb-3 mb-md-0">
                <span class="text-light"><i class="fas fa-copyright text-light me-2"></i>El Solitario de Sayan N° 81.</a> Todo los Derechos Reservados.</span>
            </div>
            
        </div>
    </div>
</div>

