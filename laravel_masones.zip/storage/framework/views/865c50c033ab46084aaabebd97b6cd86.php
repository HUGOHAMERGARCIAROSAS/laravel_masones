<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>El Solitario de Sayan</title>
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <link href="<?php echo e(asset('web_template/img/logo.jpg')); ?>" rel="icon">
    <link rel="stylesheet" href="<?php echo e(asset('login_template/css/all.css')); ?>">
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('login_template/css/adminlte.css')); ?>">

    <?php echo $__env->yieldContent('styles'); ?>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">

        <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

    <script src="<?php echo e(asset('login_template/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_template/js/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_template/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('login_template/js/adminlte.js')); ?>"></script>
    <?php echo $__env->yieldContent('scripts'); ?>


</body>

</html>
<?php /**PATH D:\laravel_masones\resources\views/layouts/layout.blade.php ENDPATH**/ ?>