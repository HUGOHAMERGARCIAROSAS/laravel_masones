
<?php $__env->startSection('styles'); ?>
    <style>
        .img-cover {
            width: 100% !important;
            height: 300px !important;
            object-fit: cover !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid page-header py-5"
        style="background: url(<?php echo e(asset('web_template/img/docencia_masonica.jpg')); ?>); background-size: cover; 
background-position: center">
        <h1 class="text-center text-white display-6">Eventos</h1>
        <ol class="breadcrumb justify-content-center mb-0 ">
            <li class="breadcrumb-item active text-white">Página Web de la A∴B∴R∴L∴S∴</li>
        </ol>
        <ol class="breadcrumb justify-content-center mb-0 ">
            <li class="breadcrumb-item active text-white">El Solitario de Sayán N° 81</li>
        </ol>
    </div>
    <div class="container-fluid fruite py-5">
        <div class="container py-5">
            <h1 class="mb-4">Listado de Eventos</h1>
            <div class="row g-4">
                <div class="col-lg-12">
                    <div class="row g-4">
                        <div class="col-lg-12">
                            <div class="row g-4 justify-content-center">
                                <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-6 col-lg-6 col-xl-4">
                                        <div class="rounded position-relative fruite-item">
                                            <div class="fruite-img">
                                                <img src="<?php echo e(asset('admin_template/img/eventos/' . $evento->imagen)); ?>"
                                                    class="img-fluid w-100 rounded-top img-cover"
                                                    alt="<?php echo e($evento->titulo); ?>">
                                            </div>
                                            <div class="text-primary bg-secondary px-3 py-1 rounded position-absolute"
                                                style="top: 10px; left: 10px;"><?php echo e($evento->fecha); ?></div>
                                            <div class="p-4 border border-secondary border-top-0 rounded-bottom">
                                                <h4><?php echo e($evento->titulo); ?></h4>
                                                <p><?php echo e(strip_tags($evento->descripcion)); ?></p>
                                                <div class="d-flex justify-content-between flex-lg-wrap">
                                                    <p class="text-dark fs-5 fw-bold mb-0"></p>
                                                    <a href="<?php echo e(route('detalle.eventos', $evento->id)); ?>"
                                                        class="btn border border-secondary rounded-pill px-3 text-primary"><i
                                                            class="fa fa-eye me-2 text-primary"></i> Ver más</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="mt-4">
                            <?php echo e($eventos->links()); ?>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_masones\resources\views/web/eventos.blade.php ENDPATH**/ ?>