<!DOCTYPE html>
<html>
<head>
    <title>Nuevo Correo</title>
</head>
<body>
    <h1>Nuevo Mensaje de Contacto</h1>
    <p><strong>Nombre:</strong> <?php echo e($data['name']); ?></p>
    <p><strong>Correo:</strong> <?php echo e($data['email']); ?></p>
    <p><strong>Teléfono:</strong> <?php echo e($data['phone']); ?></p>
    <p><strong>Asunto:</strong> <?php echo e($data['subject']); ?></p>
    <p><strong>Mensaje:</strong> <?php echo e($data['message']); ?></p>
</body>
</html><?php /**PATH D:\laravel_masones\resources\views/emails/contact.blade.php ENDPATH**/ ?>