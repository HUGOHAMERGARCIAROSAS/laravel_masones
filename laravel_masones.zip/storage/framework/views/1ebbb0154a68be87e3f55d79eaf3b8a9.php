<!-- Spinner Start -->
<div id="spinner"
    class="show w-100 vh-100 bg-white position-fixed translate-middle top-50 start-50  d-flex align-items-center justify-content-center">
    <div class="spinner-grow text-primary" role="status"></div>
</div>

<!-- Navbar start -->
<div class="container-fluid fixed-top">
    <div class="container px-0">
        <nav class="navbar navbar-light bg-white navbar-expand-xl">
            <a href="<?php echo e(route('/')); ?>" class="navbar-brand">
                <h1 class="text-primary display-6"><img src="<?php echo e(asset('web_template/Logo-81.png')); ?>"
                        alt="Logo Solitario de Sayan" class="navbar-logo" /></h1>
            </a>
            <button class="navbar-toggler py-2 px-3" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarCollapse">
                <span class="fa fa-bars text-primary"></span>
            </button>
            <div class="collapse navbar-collapse bg-white" id="navbarCollapse">
                <div class="navbar-nav mx-auto">
                    <div class="nav-item dropdown">
                        <a href="<?php echo e(route('/')); ?>"
                            class="nav-link dropdown-toggle <?= request()->is('/') || request()->is('nosotros') || request()->is('francmasoneria') || request()->is('declaracion_principios') || request()->is('templos') ? 'active' : '' ?>"
                            data-bs-toggle="dropdown">Inicio</a>
                        <div class="dropdown-menu m-0 bg-secondary rounded-0">
                            <a href="<?php echo e(route('nosotros')); ?>" class="dropdown-item">Nosotros</a>
                            <a href="<?php echo e(route('francmasoneria')); ?>" class="dropdown-item">La Francmasonería</a>
                            <a href="<?php echo e(route('declaracion_principios')); ?>" class="dropdown-item">Declaración de
                                Principios</a>
                            <a href="<?php echo e(route('templos')); ?>" class="dropdown-item">Templos</a>
                        </div>
                    </div>
                    <a href="<?php echo e(asset('masones_ilustres')); ?>"
                        class="nav-item nav-link <?= request()->is('masones_ilustres') ? 'active' : '' ?>">Masones
                        Ilustres</a>
                    <div class="nav-item dropdown">
                        <a href="#"
                            class="nav-link dropdown-toggle <?= request()->is('trabajos_masonicos') || request()->is('revistas_masonicas') || request()->is('libros_masonicos') || request()->is('videos_masonicos') || request()->is('conferencias_masonicas') ? 'active' : '' ?>"
                            data-bs-toggle="dropdown">Docencia
                            masónica</a>
                        <div class="dropdown-menu m-0 bg-secondary rounded-0">
                            <a href="<?php echo e(route('trabajos_masonicos')); ?>" class="dropdown-item">Trabajos Masónicos</a>
                            <a href="<?php echo e(route('revistas_masonicas')); ?>" class="dropdown-item">Revistas Masónicas</a>
                            <a href="<?php echo e(route('libros_masonicos')); ?>" class="dropdown-item">Libros Masónicos</a>
                            <a href="<?php echo e(route('videos_masonicos')); ?>" class="dropdown-item">Videos Masónicos</a>
                            <a href="<?php echo e(route('conferencias_masonicas')); ?>" class="dropdown-item">Conferencias
                                Masónicas</a>
                        </div>
                    </div>
                    <a href="<?php echo e(route('sanchez_carrion')); ?>"
                        class="nav-item nav-link <?= request()->is('sanchez_carrion') ? 'active' : '' ?>">Sanchez
                        Carrión</a>
                    <a href="<?php echo e(route('red_logias')); ?>"
                        class="nav-item nav-link <?= request()->is('red_logias') ? 'active' : '' ?>">Red de Logias</a>
                    <a href="<?php echo e(route('eventos')); ?>"
                        class="nav-item nav-link <?= request()->is('eventos') ? 'active' : '' ?>">Eventos</a>
                    <a href="<?php echo e(route('contactanos')); ?>"
                        class="nav-item nav-link <?= request()->is('contactanos') ? 'active' : '' ?>">Contáctanos</a>
                </div>
            </div>
        </nav>
    </div>
</div>
<!-- Navbar End -->
<?php /**PATH D:\laravel_masones\resources\views/web/layouts/header.blade.php ENDPATH**/ ?>