<style>
    /* .page-item:not(:first-child) .page-link{
        margin-left: 0!important;
    } */
    .page-item:not(:first-child) .page-link{
        margin-left: 0!important;
        margin-right: 5px!important;
    }
    .pagination a:hover:not(.active){
        color: #000;
    }
    
</style>
<?php if($paginator->hasPages()): ?>
    <nav>
        <ul class="pagination d-flex flex-wrap justify-content-center mt-5">
            
            <?php if($paginator->onFirstPage()): ?>
                <li class="page-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">
                    <span class="page-link rounded" aria-hidden="true">&laquo;</span>
                </li>
            <?php else: ?>
                <li class="page-item">
                    <a class="page-link rounded" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">&laquo;</a>
                </li>
            <?php endif; ?>

            
            <?php if($paginator->currentPage() > 2): ?>
                <li class="page-item"><a class="page-link rounded" href="<?php echo e($paginator->url(1)); ?>">1</a></li>
                <?php if($paginator->currentPage() > 3): ?>
                    <li class="page-item disabled"><span class="page-link rounded">...</span></li>
                <?php endif; ?>
            <?php endif; ?>

            
            <?php $__currentLoopData = range(1, $paginator->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($i >= $paginator->currentPage() - 1 && $i <= $paginator->currentPage() + 1): ?>
                    <?php if($i == $paginator->currentPage()): ?>
                        <li class="page-item active" aria-current="page"><span class="page-link rounded"><?php echo e($i); ?></span></li>
                    <?php else: ?>
                        <li class="page-item"><a class="page-link rounded" href="<?php echo e($paginator->url($i)); ?>"><?php echo e($i); ?></a></li>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php if($paginator->currentPage() < $paginator->lastPage() - 1): ?>
                <?php if($paginator->currentPage() < $paginator->lastPage() - 2): ?>
                    <li class="page-item disabled"><span class="page-link rounded">...</span></li>
                <?php endif; ?>
                <li class="page-item"><a class="page-link rounded" href="<?php echo e($paginator->url($paginator->lastPage())); ?>"><?php echo e($paginator->lastPage()); ?></a></li>
            <?php endif; ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <li class="page-item">
                    <a class="page-link rounded" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">&raquo;</a>
                </li>
            <?php else: ?>
                <li class="page-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
                    <span class="page-link rounded" aria-hidden="true">&raquo;</span>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
<?php endif; ?>


<?php /**PATH D:\laravel_masones\resources\views/vendor/pagination/tailwind.blade.php ENDPATH**/ ?>