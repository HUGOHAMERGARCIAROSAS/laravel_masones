<footer class="main-footer">
    <strong>Copyright &copy; 2024 <a href="https://Logiaelsolitariodesayan81.com" target="_blank">Logia El Solitario de Sayan</a>.</strong>
    Todos los derechos reservados.
    <div class="float-right d-none d-sm-inline-block">
        <b>Versión</b> 1.1.0
    </div>
</footer><?php /**PATH D:\laravel_masones\resources\views/layouts/footer.blade.php ENDPATH**/ ?>