
<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid page-header py-5"
        style="background: url(<?php echo e(asset('web_template/img/contactanos.jpg')); ?>); background-size: cover; background-position: center">
        <h1 class="text-center text-white display-6">DETALLE DE RED DE LOGIAS</h1>
        <ol class="breadcrumb justify-content-center mb-0 ">
            <li class="breadcrumb-item active text-white">Página Web de la A∴B∴R∴L∴S∴</li>
        </ol>
        <ol class="breadcrumb justify-content-center mb-0 ">
            <li class="breadcrumb-item active text-white">El Solitario de Sayán N° 81</li>
        </ol>
    </div>
    <div class="container-fluid py-5 mt-5">
        <div class="container py-5">
            <div class="row g-4 mb-5">
                <div class="col-lg-8 col-xl-9">
                    <div class="row g-4">
                        <div class="col-lg-6">
                            <div class="border rounded">
                                <img src="<?php echo e(asset('admin_template/img/red_logias/' . $logia[0]->imagen)); ?>"
                                    class="img-fluid rounded" alt="Image" />
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <h1 class="fw-bold mb-3 text-primary"><?php echo e($logia[0]->titulo); ?></h1>
                            <p class="mb-3">Fecha: <?php echo e($logia[0]->fecha); ?></p>
                            <p class="mb-4">
                                <?php echo $logia[0]->descripcion; ?>

                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-xl-3">
                    <div class="row g-4 fruite">
                        <div class="col-lg-12">
                            <h4 class="mb-4">Últimos Eventos</h4>
                            <?php $__currentLoopData = $lastEventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="d-flex align-items-center justify-content-start">
                                    <div class="rounded" style="width: 100px; height: 100px;">
                                        <a href="<?php echo e(route('detalle.eventos', $item->id)); ?>">
                                            <img src="<?php echo e(asset('admin_template/img/eventos/' . $item->imagen)); ?>"
                                                class=" rounded" alt="Image" width="80" height="80">
                                        </a>
                                    </div>
                                    <div>
                                        <a href="<?php echo e(route('detalle.eventos', $item->id)); ?>">
                                            <h6 class="mb-2 text-primary"><?php echo e($item->titulo); ?></h6>
                                        </a>
                                        <div class="d-flex mb-2">
                                            <h5 class="fw-bold me-2"><?php echo e($item->fecha); ?></h5>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex justify-content-center my-4">
                                <a href="<?php echo e(route('eventos')); ?>"
                                    class="btn border border-secondary px-4 py-3 rounded-pill text-primary w-100">Ver
                                    Todos</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel_masones\resources\views/web/detalle_red_logias.blade.php ENDPATH**/ ?>