
<?php $__env->startSection('styles'); ?>


<style>
    .img-cover {
    width: 100%;
    height: 200px; 
    object-fit: cover; 
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid page-header py-5" 
style="background: url(<?php echo e(asset('web_template/img/fondo3.jpg')); ?>); background-size: cover; 
background-position: center">
    <h1 class="text-center text-white display-6">MASONES ILUSTRES</h1>
    <ol class="breadcrumb justify-content-center mb-0 ">
        <li class="breadcrumb-item active text-white">Página Web de la A∴B∴R∴L∴S∴</li>
    </ol>
    <ol class="breadcrumb justify-content-center mb-0 ">
        <li class="breadcrumb-item active text-white">El Solitario de Sayán N° 81</li>
    </ol>
</div>
<div class="container-fluid py-5">
    <div class="container py-5">
        <div class="row g-4">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="fw-bold mb-3">
                        Masones Ilustres
                    </h1>
                    <p class="mb-4">
                        <?php echo $masones_ilustres->descripcion; ?>

                    </p>
                </div>
                <div class="col-lg-12">
                    <div class="border rounded">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="row">
                                            
                                            <?php $__currentLoopData = $detalle_masones_ilustres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-sm-3">
                                                    <div class="card">
                                                        <div class="card-body">
                                                            <a data-fancybox="gallery" href="<?php echo e(asset('admin_template/img/masones_ilustres/' . $image->archivo)); ?>">
                                                                <img src="<?php echo e(asset('admin_template/img/masones_ilustres/' . $image->archivo)); ?>" alt="Image" class="img-fluid img-cover">
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
        
                    <!-- Cargar todas las imágenes únicas para Fancybox (excluyendo las paginadas visibles) -->
                    <?php
                        $paginatedIds = $detalle_masones_ilustres->pluck('id')->toArray(); // IDs de las imágenes paginadas visibles
                    ?>
        
                    <div style="display: none;">
                        <?php $__currentLoopData = $todas_imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php if(!in_array($image->id, $paginatedIds)): ?>
                                <a data-fancybox="gallery" href="<?php echo e(asset('admin_template/img/masones_ilustres/' . $image->archivo)); ?>"></a>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
        
                    <div class="mt-4">
                        <?php echo e($detalle_masones_ilustres->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>


<!-- Fancybox CSS y JS -->
<link href="https://cdn.jsdelivr.net/npm/@fancyapps/ui/dist/fancybox.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui/dist/fancybox.umd.js"></script>

<style>
    .fancybox__thumbs {
        display: none !important;
    }

    .fancybox__thumb {
        display: none !important;
    }
</style>

<script>
   document.addEventListener("DOMContentLoaded", function () {
    Fancybox.bind('[data-fancybox="gallery"]', {
        loop: true,  // Permitir el bucle infinito de las imágenes
        thumbs: {
            autoStart: false  // Desactiva las miniaturas
        },
        toolbar: true,  // Mantén la barra de herramientas si deseas otros botones
        buttons: [
            "zoom",
            "slideShow",
            "close"  // No incluyas "thumbs" aquí para eliminar el botón de miniaturas
        ],
        Image: {
            preload: false // Pre-cargar imágenes para mejorar el rendimiento
        }
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\TRABAJOS\masones\resources\views/web/masones_ilustres.blade.php ENDPATH**/ ?>